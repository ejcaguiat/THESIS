chrome.browserAction.onClicked.addListener(function(tab) {
     chrome.cookies.getAll({},function (cookie){
        console.log(cookie.length);
        //var allCookieInfo = "";
        /*for(var i=0;i<cookie.length;i++){
            //console.log(JSON.stringify(cookie[i]));
            allCookieInfo = allCookieInfo + JSON.stringify(cookie[i]);
        }
        localStorage.allCookieInfo = allCookieInfo;*/3
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(cookie)); 
        var downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "hi.json");
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    });
});